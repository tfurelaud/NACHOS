#ifdef CHANGED

#include "thread.h"


extern int do_ThreadCreate(int f, int arg);
void do_ThreadExit();

#endif //CHANGED
