#include "syscall.h"

int main(){
  int n;
  int n2;

  GetInt(&n);

  PutInt(n);

  GetInt(&n2);

  PutInt(n2);

  return 0;
}
