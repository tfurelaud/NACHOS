#include "syscall.h"

int main(){

  PutString("Bonjour\n");
  PutString("Trop grande chaine de caractere\n");
  return 0;
  
}

